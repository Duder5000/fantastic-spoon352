        </div>
      </div>

    </div>

<!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->

    <div class="w3-col l4 img-card">
          <a href="home.php"><img src="logo.png" class="side-img"></a>
    </div>

  </body>

</html>
