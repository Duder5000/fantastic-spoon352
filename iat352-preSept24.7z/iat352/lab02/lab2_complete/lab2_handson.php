<!DOCTYPE html>

<html lang="en">
  <head>
    <title>Arrays</title>
  </head>
  <body>

    <?php
    // ----------------- START OF TASK 1 -----------------------//

    /*
      Task 1: initialize an array with 6 elements of your choice
              Print out one of the elements to make sure there are no errors
    */
      echo "<h2>Task 1: </h2>";
      $arr = array("fox", "dog", "mouse", 'cat', 'bird', 'racoon');
      echo "<p>" . $arr[0] . "</p>";

    // ----------------- END OF TASK 1 -----------------------//
    ?>

    <?php
    // ----------------- START OF TASK 2 -----------------------//

    /*
      Task 2: Use a for loop to print out all the elements in the array created in the previous task
    */
      echo "<h2>Task 2: </h2>";
      foreach($arr as $element) {
        echo "<p> $element </p>";
      }

    // ----------------- END OF TASK 2 -----------------------//
    ?>

    <?php
    // ----------------- START OF TASK 3 -----------------------//

    /*
      Task 2: Sort the array in descending order
                check if a value of your choice exists in the array
                  print a message alerting the user if the value exists or not

              Joins all the elements of the array and print it out as a string. Make sure the array is sorted.
    */
      echo "<h2>Task 3: </h2>";
      rsort($arr);
      if(in_array("fox", $arr)) {
        echo "<p>Found the value <b>fox</b> in the array</p>";
      } else {
        echo "<p><b>fox</b> is not found</p>";
      }

      $array_imploded = implode(", ", $arr);
      echo "<p>" . $array_imploded . "</p>"

    // ----------------- END OF TASK 3 -----------------------//
    ?>


    <?php
    // ----------------- START OF TASK 4 -----------------------//

    /*
      Task 4: Create an associative array with the following:
                Name of an animal
                Food the animal eats
                Place where you can find the animal
              Insert an additional index called color with any value that you want
              Then print out a sentence explaining the animal with those attributes

    */
      echo "<h2>Task 4: </h2>";
      $animal_info = array("name" => "wolf", "food" => "meat", "place" => "forest");

      $animal_info['color'] = "grey";
      echo "<p>A " . $animal_info['color'] . " " . $animal_info['name'] . " that eats " . $animal_info['food'] . " lives in a " . $animal_info['place'] . "</p>";
    // ----------------- END OF TASK 4 -----------------------//
    ?>

    <?php
    // ----------------- START OF TASK 5 -----------------------//

    /*
      Task 5: Open the file animal.txt using read mode and print a message on success
              Remeber to close the file after the message is printed

    */
      echo "<h2>Task 5: </h2>";

      $file = fopen('animal.txt', 'a');
      if(!$file) {
        echo "<p>Unable to open the file animal.txt, please try again later</p>";
        exit;
      }

      $entry = implode(",", $animal_info) . "\n";
      fwrite($file, $entry);

      fclose($file);

      $file_read = fopen('animal.txt', 'r');
      if(!$file_read) {
        echo "<p>Unable to read the file animal.txt, please try again later</p>";
        exit;
      }

      while ($entry = fgetcsv($file_read)) {
          echo "<p>animal: " . $entry[0] . "</p>";
      }

      fclose($file_read);
    // ----------------- END OF TASK 5 -----------------------//

      // Extra: If you want to combine read and append you can use a+ mode,
      // The following code shows how it could be achieved
      $file_read_and_write = fopen('animal.txt', 'a+');
      if(!$file_read_and_write) {
        echo "<p>Unable to open the file animal.txt, please try again later</p>";
        exit;
      }

      // a mode defaults the pointer of the file to the end of the file
      // so we need to reset the pointer to the start of the file using fseek() method
      fseek($file_read_and_write, 0); // 0 stands for the start of the file
      echo "<h2>Task 5 Optional: Read data with 'a+' mode</h2>";
      while ($entry = fgetcsv($file_read_and_write)) {
          echo "<p>animal: " . $entry[0] . "</p>";
      }

      fclose($file_read_and_write);
    ?>

  </body>
</html>