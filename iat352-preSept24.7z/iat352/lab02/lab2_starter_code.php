<!DOCTYPE html>

<html lang="en">
  <head>
    <title>Arrays</title>
  </head>
  <body>

    <?php
    // ----------------- START OF TASK 1 -----------------------//

    /*
      Task 1: initialize an array with 6 elements of your choice
              Print out one of the elements to make sure there are no errors
    */

      $arr1 = array("A","B","C","D","E","F");
      echo "<h2>Task 1: </h2>";
      echo $arr1[0];


    // ----------------- END OF TASK 1 -----------------------//
    ?>



    <?php
    // ----------------- START OF TASK 2 -----------------------//

    /*
      Task 2: Use a for loop to print out all the elements in the array created in the previous task
    */
      echo "<h2>Task 2: </h2>";
      
      function showArr($myArr){
        for($i = 0; $i < count($myArr); $i++){
          echo $myArr[$i] . ", ";
        }
      }

      showArr($arr1);


    // ----------------- END OF TASK 2 -----------------------//
    ?>



    <?php
    // ----------------- START OF TASK 3 -----------------------//

    /*
      Task 2: Sort the array in descending order
                check if a value of your choice exists in the array
                  print a message alerting the user if the value exists or not

              Joins all the elements of the array and print it out as a string. Make sure the array is sorted.
    */
      echo "<h2>Task 3: </h2>";
      rsort($arr1);
      
      function checkFor($e, $myArr){
        $found = 0;
        for($i = 0; $i < count($myArr); $i++){
          if ($e == $myArr[$i]){
            echo $e . " was found";
            $found = 1;
            break;
          }
        }
        if($found == 0){
          echo $e . " was not found";
        }
      }

      checkFor("C", $arr1);
      echo "</br>";
      checkFor("Q", $arr1);



    // ----------------- END OF TASK 3 -----------------------//
    ?>



    <?php
    // ----------------- START OF TASK 4 -----------------------//

    /*
      Task 4: Create an associative array with the following:
                Name of an animal
                Food the animal eats
                Place where you can find the animal
              Insert an additional index called color with any value that you want
              Then print out a sentence explaining the animal with those attributes

    */
      echo "<h2>Task 4: </h2>";
      
      $arr2 = array("animalName"=>"Dog",
        "animalFood"=>"Kibble",
        "place"=>"Parks");

      $arr2["colour"] = "Black";

      echo $arr2['animalName'] . ", " . $arr2['animalFood'] . ", " . $arr2['place'] . ", " . $arr2['colour'];

    // ----------------- END OF TASK 4 -----------------------//
    ?>



    <?php
    // ----------------- START OF TASK 5 -----------------------//

    /*
      Task 5: Turn the array in task 4 into a CSV and insert the CSV into animal.txt as a new line
              Then display all the animal names in the CSV file (there are 2 to start with)

    */
      echo "<h2>Task 5: </h2>";

      // $file1 = fopen('animal.txt', 'r');
      // // $t = fgetcsv($file1);
      // // echo($t[0]) ."</br>";  

      // while($arr3 = fgetcsv($file1)){
      //   showArr($arr3);
      //   echo "</br>";
      // }

      // fclose($file1);

      $file2 = fopen('animal4.txt', 'a');

      fwrite($file2, "\n");

      $abc = $arr2['animalName'] . ", " . $arr2['animalFood'] . ", " . $arr2['place'] . ", " . $arr2['colour'];

      fwrite($file2, $abc);

      fclose($file2);

      $file2 = fopen('animal4.txt', 'r');

      while($arr3 = fgetcsv($file2)){
        showArr($arr3);
        echo "</br>";
      }

      fclose($file1);


    // ----------------- END OF TASK 5 -----------------------//
    ?>

  </body>
</html>