<!-- form.php START -->

<html>

  <head><title>IAT 352 - Hw01 - Form</title></head>

  <body>

    <form method="post" action="hw01results.php">

        <lable>Type of Program:</lable>
          <input name="typeProgram" type="text"/></br>                      

        <lable>Langauge of Instruction:</lable>
          <input name="langauge" type="text"/></br>

        <lable>Country:</lable>
          <input name="country" type="text"/></br>

        <lable>Level of Study:</lable>
        <select name="los">
          <option value="">Level of Study</option>
          <option value="undergrad">Undergraduate</option>
          <option value="grad">Graduate</option>
          <option value="phd">PHD or Post-Doc</option>
          <option value="pdp">PDP</option>
        </select></br>

        <lable>Term:</lable>
          <input name="term" type="text"/></br>

        <input type="submit" value="submit" />

    </form>

    <?php
      
    ?>

  </body>

</html>

<!-- form.php END -->