<!-- results.php START -->

<html>

  <head><title>IAT 352 - Hw01 - Results</title></head>

  <body>

    <?php
        
      if(isset($_POST['typeProgram'])
        && isset($_POST['langauge']) 
        && isset($_POST['country'])
        && isset($_POST['los'])
        && isset($_POST['term'])) {
        
        if(empty($_POST['typeProgram']) 
          || empty($_POST['langauge'])
          || empty($_POST['country'])
          || empty($_POST['los'])
          || empty($_POST['term'])) { 
          
          echo '<p>ERROR, incomplete</p>';
        } else {
          // echo 'Show stuff';
          echo '<p>Your application is successfully submitted. The following information is listed in the application: '
            . 'Program: ' . $_POST['typeProgram']
            . ', Langauge: ' . $_POST['langauge']
            . ', Country: ' . $_POST['country']
            . ', Level of Study: ' . $_POST['los']
            . ', Term: ' . $_POST['term'];
        }
      } else {
        echo 'ERROR, stuff';
      }
    ?>

  </body>

</html>

<!-- results.php END -->