        </div>
      </div>

    </div>

<!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->

    <div class="w3-col l4 img-card">
          <a href="signup.php"><img src="logo.png" class="side-img"></a>
    </div>

  </body>

</html>
