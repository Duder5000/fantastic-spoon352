<html>

  <head><title>Lab01 Hands-on02 - Form</title></head>

  <body>

    <form method="post" action="results.php">

        <lable>School Name:</lable>
          <input name="school" type="text"/></br>

        <label>Gender: </label>
          <label>Male</label>
          <input type="radio" name="gender" value="Male"/>
          <label>Female</label>
          <input type="radio" name="gender" value="Female"/>
          <label>Other</label>
          <input type="radio" name="gender" value="Other"/></br>                          

        <lable>School Year:</lable>
        <select name="year">
          <option value="">School Year</option>
          <option value="1">First</option>
          <option value="2">Second</option>
          <option value="3">Third</option>
          <option value="4">Fourth</option>
        </select>

        <input type="submit" value="submit" />

    </form>

    <?php
      
    ?>

  </body>

</html>