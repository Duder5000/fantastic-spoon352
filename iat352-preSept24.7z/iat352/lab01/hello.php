<html>

  <head><title>Hello World IAT 352</title></head>

  <body>

    <?php
      echo '<p>Hello World</p>';
    ?>

  </body>

</html>