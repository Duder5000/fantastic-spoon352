<html>

  <head><title>Lab01 Hands-on02 - Results</title></head>

  <body>

    <?php
        
      if(isset($_POST['school']) && isset($_POST['gender']) && isset($_POST['year'])) {
        if(empty($_POST['school']) || empty($_POST['year'])){ 
          echo '<p>ERROR, incomplete</p>';
        } else {
          echo '<p>School: <b>'
            . $_POST['school']
            . '</b> Gender: <b>'
            . $_POST['gender']
            . '</b> School Year: <b>'
            . $_POST['year']
            . '</p>';
        }
      } else {
        echo '<p>ERROR, no gender selected</p>';
      }
    ?>

  </body>

</html>