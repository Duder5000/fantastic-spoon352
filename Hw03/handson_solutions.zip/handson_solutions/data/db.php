<?php
  $dbhost = "localhost"; // Or the host where you are running your db
  $dbuser = "root"; // The user we just created
  $dbpass = ""; // Leave empty if you did not specify a password
  $dbname = "classicmodels"; // DB we are working with today

?>